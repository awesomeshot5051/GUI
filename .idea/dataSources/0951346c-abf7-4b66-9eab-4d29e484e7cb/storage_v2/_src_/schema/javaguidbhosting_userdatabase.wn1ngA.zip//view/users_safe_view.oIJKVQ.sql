create definer = `409644`@`%` view users_safe_view as
select `javaguidbhosting_userdatabase`.`users`.`id`              AS `id`,
       `javaguidbhosting_userdatabase`.`users`.`username`        AS `username`,
       `javaguidbhosting_userdatabase`.`users`.`group`           AS `group`,
       `javaguidbhosting_userdatabase`.`users`.`status`          AS `status`,
       `javaguidbhosting_userdatabase`.`users`.`last_login`      AS `last_login`,
       `javaguidbhosting_userdatabase`.`users`.`expiration_time` AS `expiration_time`
from `javaguidbhosting_userdatabase`.`users`;

grant select on table users_safe_view to '409644_guest';

