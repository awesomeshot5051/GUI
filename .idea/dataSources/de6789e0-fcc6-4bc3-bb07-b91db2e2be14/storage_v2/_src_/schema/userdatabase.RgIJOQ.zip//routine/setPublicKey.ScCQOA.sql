create
    definer = avnadmin@`%` procedure setPublicKey(IN v_username text, IN v_name text, IN v_public_key text,
                                                  IN v_public_salt text)
begin

    declare user_id int;

    call getID(v_username,v_name,user_id);

    update users set public_key=v_public_key,public_salt=v_public_salt where id=user_id;

end;

