create
    definer = avnadmin@`%` procedure getUserStatus(IN p_username varchar(255), IN p_identifier varchar(255))
BEGIN
    DECLARE user_id INT;

    -- Attempt to get user ID by username and name
    CALL getID(p_username, p_identifier, user_id);

    -- If user exists, retrieve the status
    IF user_id IS NOT NULL THEN
        SELECT `status` FROM users WHERE id = user_id;
    ELSE
        -- Check if the second parameter is a password or name, and handle accordingly
        -- Check if p_identifier matches the password or name (depending on how you define them)
        Begin
            DECLARE temp_user_id INT;

            -- Try by matching p_identifier as name (if it’s not a password)
            SELECT id INTO temp_user_id
            FROM users
            WHERE username = p_username AND name = p_identifier;

            -- If user ID found with name
            IF temp_user_id IS NOT NULL THEN
                SELECT `status` FROM users WHERE id = temp_user_id;
            ELSE
                -- Try by matching p_identifier as password
                SELECT id INTO temp_user_id
                FROM users
                WHERE username = p_username AND password = p_identifier;

                -- If user ID found with password
                IF temp_user_id IS NOT NULL THEN
                    SELECT `status` FROM users WHERE id = temp_user_id;
                ELSE
                    SIGNAL SQLSTATE '45000'
                        SET MESSAGE_TEXT = 'User not found or invalid password/name';
                END IF;
            END IF;
        end;
    END IF;
END;

