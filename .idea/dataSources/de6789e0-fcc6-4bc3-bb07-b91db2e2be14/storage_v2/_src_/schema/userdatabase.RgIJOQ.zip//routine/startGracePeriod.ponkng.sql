create
    definer = avnadmin@`%` procedure startGracePeriod(IN p_subId varchar(255))
BEGIN

UPDATE access_keys
SET expires_at = DATE_ADD(NOW(), INTERVAL 3 DAY)
WHERE stripe_subscription_id = p_subId;
end;

