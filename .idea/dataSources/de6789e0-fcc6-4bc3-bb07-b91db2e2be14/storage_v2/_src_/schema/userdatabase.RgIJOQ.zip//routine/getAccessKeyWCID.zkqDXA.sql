create
    definer = avnadmin@`%` procedure getAccessKeyWCID(IN p_customer_id varchar(65), OUT p_access_key varchar(65))
begin
    select key_value into p_access_key from access_keys where id = p_customer_id;
end;

