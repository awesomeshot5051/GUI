create
    definer = avnadmin@`%` procedure updateExpirationTime(IN p_username varchar(255), IN p_name varchar(255), IN time int)
begin
    declare user_id int;
    call getID(p_username,p_name,user_id);
    UPDATE passwordexpiration
    SET
        expires_after_days = time
    WHERE
        userID = user_id;
end;

