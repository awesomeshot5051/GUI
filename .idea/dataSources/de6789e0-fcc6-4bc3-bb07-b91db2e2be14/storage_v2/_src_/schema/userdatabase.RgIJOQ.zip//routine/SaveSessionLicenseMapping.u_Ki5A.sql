create
    definer = avnadmin@`%` procedure SaveSessionLicenseMapping(IN sessionId varchar(255), IN licenseKey varchar(255))
begin
    INSERT INTO license_sessions (session_id, license_key) VALUES (sessionId, licenseKey);
end;

