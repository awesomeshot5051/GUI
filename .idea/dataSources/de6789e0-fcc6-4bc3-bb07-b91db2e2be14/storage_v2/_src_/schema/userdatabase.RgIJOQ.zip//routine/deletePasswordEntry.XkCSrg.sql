create
    definer = avnadmin@`%` procedure deletePasswordEntry(IN p_username varchar(255), IN p_name varchar(255), IN p_id int)
begin
    declare p_userId int;
    call getID(p_username,p_name,p_userId);
    delete from passwordManager where id = p_id and user_id = p_userId;
end;

