create
    definer = avnadmin@`%` procedure getAdmins()
begin
    select name,username,`group`, status from users where `group`='admin' or `group`='superadmin';
end;

