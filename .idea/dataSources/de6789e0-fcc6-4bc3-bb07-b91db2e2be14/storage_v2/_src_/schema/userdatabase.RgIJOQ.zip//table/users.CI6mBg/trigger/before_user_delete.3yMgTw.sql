create definer = avnadmin@`%` trigger before_user_delete
    before delete
    on users
    for each row
BEGIN

    DELETE FROM passwordexpiration WHERE userID = OLD.id;

END;

