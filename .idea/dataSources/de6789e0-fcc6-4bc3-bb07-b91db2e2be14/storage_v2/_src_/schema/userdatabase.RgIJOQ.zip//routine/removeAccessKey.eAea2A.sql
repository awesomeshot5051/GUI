create
    definer = avnadmin@`%` procedure removeAccessKey(IN p_key varchar(64))
begin
    delete from access_keys where key_value=p_key;
end;

