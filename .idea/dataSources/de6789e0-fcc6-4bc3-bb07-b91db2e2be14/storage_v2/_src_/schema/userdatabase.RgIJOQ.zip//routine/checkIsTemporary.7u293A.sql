create
    definer = avnadmin@`%` procedure checkIsTemporary(IN p_customer_id varchar(255), OUT p_is_temporary bit)
begin
    declare p_access_key varchar(65);
    call getAccessKeyWCID(p_customer_id,p_access_key);
    select access_keys.is_temporary into p_is_temporary from access_keys where key_value=p_access_key and customer_id=p_customer_id;
end;

