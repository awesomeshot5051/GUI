create
    definer = avnadmin@`%` procedure updateGlobalExpirationTime(IN time int)
begin

    UPDATE passwordexpiration

    SET

        expires_after_days = time;

end;

