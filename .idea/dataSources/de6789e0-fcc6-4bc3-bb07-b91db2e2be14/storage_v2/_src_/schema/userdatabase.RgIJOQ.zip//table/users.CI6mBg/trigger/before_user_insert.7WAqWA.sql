create definer = avnadmin@`%` trigger before_user_insert
    before insert
    on users
    for each row
BEGIN
    DECLARE superadmin_count INT;
    SELECT COUNT(*) INTO superadmin_count FROM users WHERE `group` = 'SuperAdmin';
    -- If there is already a SuperAdmin and trying to add another one
    IF superadmin_count >= 1 AND NEW.`group` = 'SuperAdmin' THEN
        SET NEW.`group` = 'Admin';
    END IF;
END;

