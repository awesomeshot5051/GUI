create
    definer = avnadmin@`%` procedure GetLicenseKeyBySessionId(IN p_session_id varchar(255))
BEGIN
    SELECT license_key
    FROM license_sessions
    WHERE session_id = p_session_id;
END;

