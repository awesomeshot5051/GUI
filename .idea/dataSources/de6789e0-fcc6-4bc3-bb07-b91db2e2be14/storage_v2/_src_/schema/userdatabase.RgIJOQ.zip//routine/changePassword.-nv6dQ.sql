create
    definer = avnadmin@`%` procedure changePassword(IN p_username varchar(255), IN p_name varchar(255),
                                                    IN p_newPassword varchar(255))
BEGIN
    DECLARE user_id INT;

    -- Retrieve the user ID from the username
    CALL getID(p_username, p_name, user_id);

    -- Check if user exists
    IF user_id IS NOT NULL THEN
        -- Update the password
        UPDATE users SET password = p_newPassword WHERE id = user_id;

        -- Correct way to update expiration time
        CALL updateExpirationTime(
                p_username,
                p_name,
                DATE_ADD(NOW(), INTERVAL getPasswordExpirationDays(p_username) DAY)
             );
    ELSE
        -- Handle case where user is not found
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'User not found';
    END IF;
END;

