create
    definer = avnadmin@`%` procedure checkUserExists(IN p_username varchar(255), OUT userExists int)
BEGIN

    SELECT COUNT(*) INTO userExists FROM users WHERE username = p_username;

END;

