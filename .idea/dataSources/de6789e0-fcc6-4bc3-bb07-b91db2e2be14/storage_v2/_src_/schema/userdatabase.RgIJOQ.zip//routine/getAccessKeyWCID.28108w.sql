create
    definer = avnadmin@`%` procedure getAccessKeyWCID(IN p_customer_id varchar(255), OUT p_access_key varchar(65))
begin
    select key_value into p_access_key from access_keys where customer_id = p_customer_id;
end;

