create definer = avnadmin@`%` trigger before_user_update
    before update
    on users
    for each row
BEGIN
    DECLARE superadmin_count INT;
    -- Count SuperAdmins, excluding the current row (in case it *is* SuperAdmin already)
    SELECT COUNT(*) INTO superadmin_count

    FROM users
    WHERE `group` = 'SuperAdmin' AND id != OLD.id;
    -- If another SuperAdmin exists and trying to change this user to SuperAdmin
    IF superadmin_count >= 1 AND NEW.`group` = 'SuperAdmin' THEN
        SET NEW.`group` = 'Admin';
    END IF;
END;

