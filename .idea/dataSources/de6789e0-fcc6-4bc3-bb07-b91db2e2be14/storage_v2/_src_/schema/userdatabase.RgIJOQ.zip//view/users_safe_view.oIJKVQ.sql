create definer = avnadmin@`%` view users_safe_view as
select `userdatabase`.`users`.`id`              AS `id`,
       `userdatabase`.`users`.`username`        AS `username`,
       `userdatabase`.`users`.`group`           AS `group`,
       `userdatabase`.`users`.`status`          AS `status`,
       `userdatabase`.`users`.`last_login`      AS `last_login`,
       `userdatabase`.`users`.`expiration_time` AS `expiration_time`
from `userdatabase`.`users`;

