create
    definer = avnadmin@`%` procedure logIP(IN ip varchar(255), IN access_key varchar(255))
begin

    insert into userIPLogging (ip, access_key) values (ip, access_key);

end;

