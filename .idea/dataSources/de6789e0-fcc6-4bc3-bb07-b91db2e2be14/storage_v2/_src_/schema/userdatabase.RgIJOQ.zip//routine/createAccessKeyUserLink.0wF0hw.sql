create
    definer = avnadmin@`%` procedure createAccessKeyUserLink(IN p_username varchar(255), IN p_name varchar(255),
                                                             IN p_accessKey varchar(255))
BEGIN
    DECLARE p_id INT;
    DECLARE a_id INT;

    -- Get user ID
    CALL getID(p_username, p_name, p_id);

    -- Get access key ID
    SELECT id INTO a_id FROM access_keys WHERE key_value = p_accessKey;

    -- Check if a link already exists
    IF NOT EXISTS (
        SELECT 1 FROM user_access_keys
        WHERE user_id = p_id OR access_key_id = a_id
    ) THEN
        INSERT INTO user_access_keys(user_id, access_key_id)
        VALUES (p_id, a_id);
    END IF;
END;

