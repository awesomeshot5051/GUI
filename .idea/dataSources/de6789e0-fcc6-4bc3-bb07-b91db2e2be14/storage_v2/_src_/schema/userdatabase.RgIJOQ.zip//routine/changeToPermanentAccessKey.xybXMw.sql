create
    definer = avnadmin@`%` procedure changeToPermanentAccessKey(IN p_subscription_id varchar(255))
BEGIN
    DECLARE proposed_expiration DATE;
    DECLARE today_month INT;
    DECLARE expiration_month INT;
    DECLARE p_key_value varchar(255);
    call getAccessKeyWCID(p_subscription_id,p_key_value);
    SET proposed_expiration = DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 1 MONTH), '%Y-%m-01');
    SET today_month = MONTH(NOW());
    SET expiration_month = MONTH(proposed_expiration);

    -- If proposed expiration month is the same as today’s month (meaning today is near the end of the month)
    -- then push to the *following* 1st
    IF expiration_month = today_month THEN
        SET proposed_expiration = DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 2 MONTH), '%Y-%m-01');
    END IF;

    update access_keys set
               access_keys.key_value=p_key_value,
               access_keys.is_temporary=FALSE,
               access_keys.createdAt=NOW(),
               access_keys.expires_at=proposed_expiration,
               access_keys.customer_id=p_subscription_id
    where access_keys.customer_id=p_subscription_id;

END;

