create
    definer = avnadmin@`%` procedure renewSubscription(IN p_subId varchar(255))
begin
UPDATE access_keys
SET expires_at = (
    IF(MONTH(DATE_ADD(NOW(), INTERVAL 1 MONTH)) = MONTH(NOW()),
       DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 2 MONTH), '%Y-%m-01'),
       DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 1 MONTH), '%Y-%m-01'))
    )
WHERE customer_id = p_subId;
end;

