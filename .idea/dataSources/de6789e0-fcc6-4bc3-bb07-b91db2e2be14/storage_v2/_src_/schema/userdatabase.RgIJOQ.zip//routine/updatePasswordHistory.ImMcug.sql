create
    definer = avnadmin@`%` procedure updatePasswordHistory(IN p_username varchar(255), IN p_name varchar(255),
                                                           IN v_password_history_limit int)
begin
    declare userID int;
    call getID(p_username,p_name,userID);
    update password_history set password_history_limit=v_password_history_limit where user_id=userID;
end;

