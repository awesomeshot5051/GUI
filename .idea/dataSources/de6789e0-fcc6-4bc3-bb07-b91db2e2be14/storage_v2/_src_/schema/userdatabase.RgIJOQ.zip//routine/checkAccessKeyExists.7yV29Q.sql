create
    definer = avnadmin@`%` procedure checkAccessKeyExists(IN p_access_key varchar(41), OUT p_exists tinyint(1))
BEGIN
    DECLARE v_count INT;

    SELECT COUNT(*) INTO v_count
    FROM access_keys
    WHERE key_value = p_access_key;

    SET p_exists = (v_count > 0);
END;

