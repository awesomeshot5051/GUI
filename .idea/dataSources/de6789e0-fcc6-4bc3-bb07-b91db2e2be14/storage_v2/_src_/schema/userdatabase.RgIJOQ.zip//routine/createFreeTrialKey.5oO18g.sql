create
    definer = avnadmin@`%` procedure createFreeTrialKey(IN p_licenseKey varchar(255), IN p_customerId varchar(255))
begin
    insert into access_keys(key_value,is_temporary,customer_id,created_at,expires_at) values(p_licenseKey,1,p_customerId,now(),now() + interval 7 day);
end;

