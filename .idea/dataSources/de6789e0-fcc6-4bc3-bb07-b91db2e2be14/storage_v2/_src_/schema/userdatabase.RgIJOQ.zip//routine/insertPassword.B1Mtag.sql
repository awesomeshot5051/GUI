create
    definer = avnadmin@`%` procedure insertPassword(IN p_username varchar(512), IN p_name varchar(512),
                                                    IN p_encrypted_login varbinary(512),
                                                    IN p_encrypted_password varbinary(512),
                                                    IN p_encrypted_website varbinary(512),
                                                    IN p_encrypted_notes varbinary(2048),
                                                    IN p_encrypted_label varbinary(2048), IN p_password_strength int,
                                                    IN p_last_accessed date)
BEGIN
    DECLARE v_user_id INT;

    call getID(p_username, p_name,v_user_id);

    -- If still not found, abort
    IF v_user_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'User not found.';
    END IF;

    -- Insert into passwordManager
    INSERT INTO passwordManager (
        user_id,
        website,
        username,
        password,
        password_label,
        notes,
        password_strength,
        last_accessed
    ) VALUES (
                 v_user_id,
                 p_encrypted_website,
                 p_encrypted_login,
                 p_encrypted_password,
              p_encrypted_label,
                 p_encrypted_notes,
                 p_password_strength,
                 p_last_accessed
             );
END;

