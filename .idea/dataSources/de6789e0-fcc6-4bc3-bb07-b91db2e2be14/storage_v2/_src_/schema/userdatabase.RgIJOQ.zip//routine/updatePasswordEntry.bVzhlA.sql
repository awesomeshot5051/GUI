create
    definer = avnadmin@`%` procedure updatePasswordEntry(IN p_id int, IN p_username varchar(255),
                                                         IN p_name varchar(255), IN p_website varbinary(512),
                                                         IN p_login varbinary(512), IN p_password varbinary(512),
                                                         IN p_label varbinary(255), IN p_notes varbinary(2048),
                                                         IN p_strength varbinary(3), IN p_last_accessed varbinary(32))
BEGIN
    DECLARE p_userId INT;

    -- Resolve user_id from plaintext name + username
    CALL getId(p_username, p_name, p_userId);

    -- Make sure the row belongs to the user before updating
    UPDATE passwordManager
    SET
        website          = IF(p_website IS NOT NULL, p_website, website),
        username         = IF(p_login IS NOT NULL, p_login, username),
        password         = IF(p_password IS NOT NULL, p_password, password),
        password_label   = IF(p_label IS NOT NULL, p_label, password_label),
        notes            = IF(p_notes IS NOT NULL, p_notes, notes),
        password_strength= IF(p_strength IS NOT NULL, p_strength, password_strength),
        last_accessed    = IF(p_last_accessed IS NOT NULL, p_last_accessed, last_accessed),
        updated_at       = CURRENT_TIMESTAMP
    WHERE user_id = p_userId and id=p_id;
END;

