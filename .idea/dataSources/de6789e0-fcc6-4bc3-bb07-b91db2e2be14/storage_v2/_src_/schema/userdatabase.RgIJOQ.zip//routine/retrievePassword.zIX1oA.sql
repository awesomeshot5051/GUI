create
    definer = avnadmin@`%` procedure retrievePassword(IN p_username varchar(255), IN p_name varchar(255))
begin

declare p_userId int;
call getId(p_username,p_name,p_userId);
    select id,Website, Username, Password, password_label, Notes, password_strength, last_accessed from passwordManager where user_id=p_userId;
end;

