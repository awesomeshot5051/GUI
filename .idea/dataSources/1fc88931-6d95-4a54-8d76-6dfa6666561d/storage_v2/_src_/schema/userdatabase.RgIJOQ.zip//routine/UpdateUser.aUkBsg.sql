create
    definer = root@localhost procedure UpdateUser(IN p_username varchar(255), IN p_name varchar(255),
                                                  IN p_group varchar(255), IN p_status varchar(255))
BEGIN
    -- Prevent updating the SuperAdmin group
    IF p_group = 'SuperAdmin' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'SuperAdmin group cannot be modified';
    END IF;

    -- Declare variable to store the id
    begin
    DECLARE user_id INT;

    -- Retrieve the user's id based on the username
    call getID(p_username,p_name,user_id);

    -- If the ID is found, perform the update
    IF user_id IS NOT NULL THEN
        UPDATE users
        SET `group` = p_group, status = p_status
        WHERE id = user_id;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'User not found';
    END IF;
    end;
END;

