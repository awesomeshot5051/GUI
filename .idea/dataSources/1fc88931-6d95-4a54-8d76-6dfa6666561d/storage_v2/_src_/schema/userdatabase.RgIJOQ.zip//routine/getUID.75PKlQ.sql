create
    definer = root@localhost procedure getUID(IN p_username varchar(255), IN p_password varchar(255), OUT user_id int)
begin
select id from users where username=p_username into user_id;
end;

