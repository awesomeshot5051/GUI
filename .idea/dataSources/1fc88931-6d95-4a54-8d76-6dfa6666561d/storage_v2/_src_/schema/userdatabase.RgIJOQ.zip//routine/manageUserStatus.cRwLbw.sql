create
    definer = root@localhost procedure manageUserStatus(IN p_username varchar(255), IN p_name varchar(255),
                                                        IN new_status varchar(255))
BEGIN
    DECLARE user_id INT;

    -- Retrieve the user ID from the username
    call getID(p_username,p_name,user_id);

    IF user_id IS NOT NULL THEN
        UPDATE users SET status = new_status WHERE id = user_id;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'User not found';
    END IF;
END;

