create
    definer = root@localhost procedure getPasswordExpiration(IN p_username varchar(255), IN p_password varchar(255))
begin
	declare user_id int;
    select id into user_id from users where username=p_username and password=p_password;
    select nextChangeDate from passwordExpiration where userID=user_id;
end;

