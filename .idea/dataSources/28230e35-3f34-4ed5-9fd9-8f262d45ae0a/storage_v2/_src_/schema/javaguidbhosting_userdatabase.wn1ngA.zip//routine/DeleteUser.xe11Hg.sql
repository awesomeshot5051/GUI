create
    definer = `409644`@`%` procedure DeleteUser(IN p_username varchar(255), IN p_name varchar(255),
                                                IN p_current_user varchar(255))
BEGIN
declare user_id int;
    DECLARE user_group VARCHAR(255);
	call getID(p_username, p_name, user_id);
    -- Get the group of the user being deleted
SELECT 
    `group`
INTO user_group FROM
    users
WHERE
    id=user_id;

    -- Prevent deletion of protected users
    IF user_group = 'SuperAdmin' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'SuperAdmin cannot be deleted';
    ELSEIF p_username = p_current_user THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'You cannot delete your own account';
    ELSEIF user_group = 'Default' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Users in the Default group cannot be deleted';
    ELSE
        -- Delete the user
        DELETE FROM users WHERE username = p_username AND id=user_id;
    END IF;

END;

