create
    definer = `409644`@`%` procedure getID(IN p_username varchar(255), IN p_name varchar(255), OUT user_id int)
begin
select id from users where username=p_username and name=p_name into user_id;
end;

