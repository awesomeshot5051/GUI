create
    definer = `409644`@`%` procedure createUser(IN p_name varchar(50), IN p_username varchar(50),
                                                IN p_password varchar(125), IN p_group varchar(255),
                                                IN p_status enum ('Enabled', 'Disabled'), IN p_salt varchar(32),
                                                IN p_expiration_time varchar(50), IN p_expires_after_days int)
BEGIN
    DECLARE new_user_id INT;

    -- Insert into users table
    INSERT INTO users (name, username, password, `group`, status, salt, expiration_time)
    VALUES (p_name, p_username, p_password, p_group, p_status, p_salt, p_expiration_time);

    -- Get the last inserted user ID
    SET new_user_id = LAST_INSERT_ID();

    -- Insert into passwordExpiration table
    INSERT INTO passwordexpiration (
        userID, password, lastChangedDate, expires_after_days
    ) VALUES (
                 new_user_id, p_password, CURDATE(), p_expires_after_days
             );
END;

