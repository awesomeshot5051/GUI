create
    definer = `409644`@`%` procedure changePassword(IN p_username varchar(255), IN p_name varchar(255),
                                                    IN p_newPassword varchar(255))
BEGIN
    DECLARE user_id INT;

    -- Retrieve the user ID from the username
    call getID(p_username, p_name, user_id);

    -- Check if user exists
    IF user_id IS NOT NULL THEN
        -- Update the password
        UPDATE users SET password = p_newPassword WHERE id = user_id;
        call updateExpirationTime(p_username,p_name);
    ELSE
        -- Handle case where user is not found
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'User not found';
    END IF;
END;

