create definer = `409644`@`%` trigger enforce_password_history_limit
    before insert
    on password_history
    for each row
BEGIN
    DECLARE limit_val INT;

    -- Prevent inserts for protected users (user_id = 0 or 1)
    IF NEW.user_id IN (0, 1) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Inserts for protected users (ID 0 and 1) are not allowed.';
    ELSE
        -- Get the user's password history limit
        SET limit_val = (
            SELECT password_history_limit
            FROM password_history
            WHERE user_id = NEW.user_id
            ORDER BY created_at DESC
            LIMIT 1
        );

        -- Default to 5 if no limit found
        IF limit_val IS NULL THEN
            SET limit_val = 5;
        END IF;

        -- If user already has password history entries at the limit, delete the oldest
        IF (
               SELECT COUNT(*) FROM password_history WHERE user_id = NEW.user_id
           ) >= limit_val THEN
            DELETE FROM password_history
            WHERE id = (
                SELECT id FROM (
                                   SELECT id
                                   FROM password_history
                                   WHERE user_id = NEW.user_id
                                   ORDER BY created_at ASC
                                   LIMIT 1
                               ) AS subquery
            );
        END IF;
    END IF;
END;

