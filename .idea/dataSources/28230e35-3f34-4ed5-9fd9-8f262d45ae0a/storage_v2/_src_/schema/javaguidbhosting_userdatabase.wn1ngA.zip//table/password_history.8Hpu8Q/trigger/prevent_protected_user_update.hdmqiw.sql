create definer = `409644`@`%` trigger prevent_protected_user_update
    before update
    on password_history
    for each row
BEGIN
    -- For protected users (0 and 1), prevent changes by forcing NEW = OLD
    IF OLD.user_id IN (0, 1) THEN
        SET NEW.user_id = OLD.user_id;
        SET NEW.password = OLD.password;
        SET NEW.created_at = OLD.created_at;
        SET NEW.password_history_limit = OLD.password_history_limit;
    END IF;
END;

