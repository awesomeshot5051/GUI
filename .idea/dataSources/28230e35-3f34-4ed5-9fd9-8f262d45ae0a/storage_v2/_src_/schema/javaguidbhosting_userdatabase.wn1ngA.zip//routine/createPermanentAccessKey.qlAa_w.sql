create
    definer = `409644`@`%` procedure createPermanentAccessKey(IN p_key_value varchar(64))
begin
    insert into access_keys (key_value, is_temporary, created_at, expires_at)
        values (p_key_value,false,now(),null);
end;

