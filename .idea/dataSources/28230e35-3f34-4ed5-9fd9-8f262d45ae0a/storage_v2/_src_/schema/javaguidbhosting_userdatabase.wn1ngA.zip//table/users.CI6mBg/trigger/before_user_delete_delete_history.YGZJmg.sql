create definer = `409644`@`%` trigger before_user_delete_delete_history
    before delete
    on users
    for each row
BEGIN
    -- Delete all entries in the 'password_history' table
    -- where the user_id matches the id of the user being deleted (OLD.id)
    DELETE FROM password_history WHERE user_id = OLD.id;
END;

