create
    definer = `409644`@`%` procedure removeAccessKey(IN p_key varchar(64))
begin
    delete from access_keys where key_value=p_key;
end;

