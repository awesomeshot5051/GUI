create
    definer = `409644`@`%` procedure updateLastChangedDate(IN p_username varchar(100), IN p_name varchar(100))
begin
    declare p_uid int;
    call getID(p_username,p_name,p_uid);
    update passwordexpiration set lastChangedDate=CURRENT_DATE where userID=p_uid;
end;

