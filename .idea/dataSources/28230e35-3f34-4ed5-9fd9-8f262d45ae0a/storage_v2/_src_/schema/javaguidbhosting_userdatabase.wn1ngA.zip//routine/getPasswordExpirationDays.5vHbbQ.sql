create
    definer = `409644`@`%` procedure getPasswordExpirationDays(IN p_username varchar(255))
begin
    declare p_password varchar(255);
    declare user_id int;
    select users.password into p_password from users where username=p_username;
    select id into user_id from users where username=p_username and password=p_password;
    select expires_after_days from passwordexpiration where userID=user_id;
end;

