create definer = `409644`@`%` trigger protectProtectedAccounts
    before update
    on passwordexpiration
    for each row
BEGIN
    -- ????️ Prevent updating expires_after_days for protected IDs
    IF OLD.userID IN (0, 1) AND NEW.expires_after_days != OLD.expires_after_days THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cannot update expires_after_days for protected accounts (ID 0 and 1)';
    END IF;

END;

