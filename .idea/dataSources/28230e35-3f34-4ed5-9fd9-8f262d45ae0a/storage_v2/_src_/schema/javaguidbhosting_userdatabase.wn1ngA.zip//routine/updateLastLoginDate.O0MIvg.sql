create
    definer = `409644`@`%` procedure updateLastLoginDate(IN v_day date, IN v_name varchar(255), IN v_username varchar(255))
begin
    declare user_id int;
    call getID(v_username, v_name, user_id);
    update users set last_login=v_day where id=user_id;
end;

