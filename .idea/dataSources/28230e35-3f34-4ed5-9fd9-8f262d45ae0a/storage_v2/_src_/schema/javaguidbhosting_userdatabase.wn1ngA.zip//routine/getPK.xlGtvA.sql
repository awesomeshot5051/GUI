create
    definer = `409644`@`%` procedure getPK(IN v_username text, IN v_name text)
begin
        declare user_id int;
        call getID(v_username,v_name,user_id);
        select users.public_key,users.public_salt from users where id=user_id;
    end;

