create
    definer = `409644`@`%` procedure ChangeUsername(IN p_salt varchar(255), IN p_newUsername varchar(255),
                                                    IN p_oldUsername varchar(255))
BEGIN
    DECLARE user_id INT;

    -- Retrieve user ID based on the old username and salt
    SELECT id INTO user_id 
    FROM users 
    WHERE username = p_oldUsername AND salt = p_salt 
    LIMIT 1;

    -- If a matching user is found, update their username
    IF user_id IS NOT NULL THEN
        UPDATE users
        SET username = p_newUsername
        WHERE id = user_id;
    END IF;
END;

