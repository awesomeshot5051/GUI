create
    definer = `409644`@`%` procedure getLastLoginDate(IN v_name varchar(255), IN v_username varchar(255))
begin
declare user_id int;
call getID(v_username,v_name,user_id);
select last_login from users where id=user_id;
end;

