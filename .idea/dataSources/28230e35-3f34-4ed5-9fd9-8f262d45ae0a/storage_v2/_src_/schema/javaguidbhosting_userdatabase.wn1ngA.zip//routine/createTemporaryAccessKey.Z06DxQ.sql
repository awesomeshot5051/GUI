create
    definer = `409644`@`%` procedure createTemporaryAccessKey(IN p_key_value varchar(64))
BEGIN
    INSERT INTO access_keys (
        key_value, is_temporary, created_at, expires_at
    ) VALUES (
                 p_key_value, TRUE, NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY)
             );
END;

