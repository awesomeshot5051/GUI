create definer = `409644`@`%` trigger control_protected_users_update
    before update
    on users
    for each row
BEGIN
    -- Allow updates normally for ID 0
    IF OLD.id = 0 THEN
        -- Allow all changes for user 0
        SET NEW.id = OLD.id;

    ELSEIF OLD.id = 1 THEN
        -- Allow updating 'status' and 'last_login' for user 1
        IF (NEW.name <> OLD.name
            OR NEW.username <> OLD.username
            OR NEW.password <> OLD.password
            OR NEW.group <> OLD.group
            OR NEW.salt <> OLD.salt
            OR NEW.expiration_time <> OLD.expiration_time) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Only the status and last_login fields can be updated for protected user ID 1.';
        END IF;
    END IF;
END;

