create
    definer = `409644`@`%` procedure updateGlobalPasswordHistory(IN v_password_history_limit int)
begin

    update password_history set password_history_limit=v_password_history_limit;
end;

